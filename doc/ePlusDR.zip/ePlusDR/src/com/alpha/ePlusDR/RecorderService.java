package com.alpha.ePlusDR;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;

/**
 * Created by beetle on 2015/2/5.
 */
public class RecorderService extends Service {


    private DebugLogger mLogger = DebugLogger.getInstance();
    //private Recorder mRecorder;


    @Override
    public IBinder onBind(Intent intent) {
        mLogger.logging("Service onBind");
        return null;
    }


    @Override
    public void onCreate() {
        mLogger.logging("Service onCreate");
        super.onCreate();
        //mRecorder = new Recorder();

        ServiceReceiver mReceiver = new ServiceReceiver();
        IntentFilter mFilter = new IntentFilter();
        mFilter.addAction(DrivingRecorder.RECORD_CTL);
        registerReceiver(mReceiver,mFilter);
        mLogger.logging("RegisterReceiver success");


    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        mLogger.logging("Service Start");
        //mRecorder.start();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        mLogger.logging("Service Stop");
        //mRecorder.stop();
        super.onDestroy();
    }

    public class ServiceReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            //todo
            //收到前台指令,执行相应操作
            if(intent.getBooleanExtra("record",true))
                mLogger.logging("receiver record command");
            else
                mLogger.logging("receiver stop command");
        }
    }
}
