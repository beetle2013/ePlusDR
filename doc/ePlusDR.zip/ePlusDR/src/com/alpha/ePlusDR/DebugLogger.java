package com.alpha.ePlusDR;

import android.os.Environment;
import de.mindpipe.android.logging.log4j.LogConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.io.File;

/**
 * Created by beetle on 2015/2/7.
 */
public class DebugLogger {

    private Logger mLogger;
    private static DebugLogger mDebugLogger = null;

    private DebugLogger() {
        initLogger();
    }

    //返回单例类实例
    public static DebugLogger getInstance() {
        if (mDebugLogger == null)
            mDebugLogger = new DebugLogger();
        return mDebugLogger;
    }

    //初始化Logger
    private void initLogger() {
        final LogConfigurator mlogConfig = new LogConfigurator();
        mlogConfig.setFileName(Environment.getExternalStorageDirectory() + File.separator + "ePlusDR.log");
        mlogConfig.setRootLevel(Level.DEBUG);
        mlogConfig.setLevel("org.apache", Level.ERROR);
        mlogConfig.configure();
        mLogger = Logger.getLogger(this.getClass());
    }

    //记录Debug信息
    public void logging(String debugInfo){
        mLogger.debug(debugInfo);
    }
}
