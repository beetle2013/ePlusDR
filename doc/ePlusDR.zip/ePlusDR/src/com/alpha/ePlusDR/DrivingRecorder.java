package com.alpha.ePlusDR;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.*;
import android.widget.Button;
import android.widget.FrameLayout;


public class DrivingRecorder extends Activity {

    //private CameraPreview mPreview;
    //private DebugLogger mLogger = DebugLogger.getInstance();
    private boolean isRecording = false;
    private Intent mIntent;

    public static final String RECORD_CTL = "com.alpha.ePlusDR.RECORD_CTL";
    public static final String RECORD_STAT = "com.alpha.ePlusDR.RECORD_STAT";


    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //mLogger.logging("DrivingRecorder onCreate");
        /**requestWindowFeature(Window.FEATURE_NO_TITLE);//隐藏标题
         getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
         WindowManager.LayoutParams.FLAG_FULLSCREEN);//设置全屏
         getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//设置屏幕常亮
         setContentView(R.layout.main);*/

        //创建广播监听服务,获得服务状态信息
        /**ActivityReceiver mReceiver = new ActivityReceiver();
        IntentFilter mFilter = new IntentFilter();
        mFilter.addAction(RECORD_STAT);
        registerReceiver(mReceiver, mFilter);*/

        //mIntent = new Intent(this, RecorderService.class);
        //startService(mIntent);

        Button captureButton = (Button) findViewById(R.id.button_capture);
        //有点击时向服务发送命令，以开始或停止录像
        //mLogger.logging("abc");
        captureButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

            }
            /**Intent mIntent = new Intent(RECORD_CTL);

            @Override
            public void onClick(View v) {
                if (isRecording) {
                    //如果在录,则停止
                    mIntent.putExtra("record",true);
                    isRecording = false;
                } else {
                    //开始录像
                    mIntent.putExtra("record",false);
                    isRecording = true;
                }
                sendBroadcast(mIntent);


            }*/
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        //mLogger.logging("DrivingRecorder onStart");
        //begin();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(!isRecording)
            stopService(mIntent);

    }

    /**
     * private void begin() {
     * mLogger.logging("begin");
     * //mRecorder.setPreview(this);
     * //mPreview = mRecorder.getPreview();
     * //FrameLayout preview = (FrameLayout) findViewById(R.id.camera_preview);
     * //preview.addView(mPreview);
     * <p/>
     * mIntent = new Intent(this, RecorderService.class);
     * <p/>
     * // Add a listener to the Capture button
     * Button captureButton = (Button) findViewById(R.id.button_capture);
     * if (mRecorder.isRecording())
     * setCaptureButtonText(getResources().getString(R.string.stop));
     * else
     * setCaptureButtonText(getResources().getString(R.string.start));
     * <p/>
     * captureButton.setOnClickListener(new View.OnClickListener() {
     *
     * @Override public void onClick(View v) {
     * if (mRecorder.isRecording()) {
     * //停止服务
     * mLogger.logging("stopService");
     * stopService(mIntent);
     * setCaptureButtonText(getResources().getString(R.string.start));
     * <p/>
     * } else {
     * //启动服务
     * mLogger.logging("startService");
     * startService(mIntent);
     * setCaptureButtonText(getResources().getString(R.string.stop));
     * <p/>
     * }
     * }
     * });
     */


    @Override
    protected void onDestroy() {
        super.onDestroy();
        //mLogger.logging("DrivingRecorder onDestroy");
        //getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    //设置Button文字
    private void setCaptureButtonText(String name) {
        Button capture = (Button) findViewById(R.id.button_capture);
        capture.setText(name);

    }

    /**public class ActivityReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {

            //todo
            //收到服务状态，界面更新
        }
    }*/


}