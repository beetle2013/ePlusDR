package com.alpha.ePlusDR;


import android.content.Context;
import android.hardware.Camera;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.os.Environment;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by beetle on 2015/2/5.
 */
public class Recorder {

    private Camera mCamera;
    private MediaRecorder mMediaRecorder;
    private CameraPreview mPreview;
    private DebugLogger mLogger = DebugLogger.getInstance();
    private boolean isRecording = false;


    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_VIDEO = 2;

    /**
     * 构造函数
     * 初始化变量
     */
    public Recorder() {
        mCamera = getCameraInstance();
        mMediaRecorder = new MediaRecorder();
    }

    public void setPreview(Context mContext){
        mPreview = new CameraPreview(mContext,mCamera);
    }
    public CameraPreview getPreview() {
        return mPreview;
    }

    public boolean isRecording(){
        return isRecording;
    }


    //开始录像
    public void start() {
        mLogger.logging("Recorder start" +  new SimpleDateFormat("HHmmss").format(new Date()));
        if (prepareVideoRecorder()) {
            // Camera is available and unlocked, MediaRecorder is prepared,
            // now you can start recording
            mMediaRecorder.start();
            isRecording = true;
            // inform the user that recording has started

        } else {
            // prepare didn't work, release the camera
            releaseMediaRecorder();

        }
    }

    //停止录像
    public void stop() {
        mLogger.logging("Recorder stop" +  new SimpleDateFormat("HHmmss").format(new Date()));
        mMediaRecorder.stop();
        // stop the recording
        releaseMediaRecorder();
        // release the MediaRecorder object
        mCamera.lock();
        isRecording = false;
    }

    protected void onPause() {
        mLogger.logging("Recorder onPause");
        releaseMediaRecorder();
        // if you are using MediaRecorder, release it first
        releaseCamera();
    }


    private boolean prepareVideoRecorder() {
        mLogger.logging("Recorder prepareVideoRecorder");

        // Step 1: Unlock and set camera to MediaRecorder
        mCamera.unlock();
        mMediaRecorder.setCamera(mCamera);
        // Step 2: Set sources
        mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
        mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);
        // Step 3: Set a CamcorderProfile (requires API Level 8 or higher)
        mMediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_HIGH));
        // Step 4: Set output file
        mMediaRecorder.setOutputFile(getOutputMediaFile(MEDIA_TYPE_VIDEO).toString());
        // Step 5: Set the preview output
        mMediaRecorder.setPreviewDisplay(mPreview.getHolder().getSurface());
        // Step 6: Prepare configured MediaRecorder
        try {
            mMediaRecorder.prepare();

        } catch (IllegalStateException e) {
            mLogger.logging("IllegalStateException preparing MediaRecorder: " + e.getMessage());
            releaseMediaRecorder();
            return false;
        } catch (IOException e) {
            mLogger.logging("IOException preparing MediaRecorder: " + e.getMessage());
            releaseMediaRecorder();
            return false;
        }
        return true;
    }


    //release the MediaRecorder
    private void releaseMediaRecorder() {
        mLogger.logging("Recorder releaseMediaRecorder");
        if (mMediaRecorder != null) {
            mMediaRecorder.reset();
            // clear recorder configuration
            mMediaRecorder.release(); // release the recorder object
            mMediaRecorder = null;
            mCamera.lock();           // lock camera for later use
        }
    }

    //release the Camera
    private void releaseCamera() {
        mLogger.logging("Recorder releaseCamera");
        if (mCamera != null) {
            mCamera.release();
            // release the camera for other applications
            mCamera = null;
        }
    }

    /**
     * Create a File for saving an image or video
     */
    private static File getOutputMediaFile(int type) {
        // To be safe, you should check that the SDCard is mounted
        // using Environment.getExternalStorageState() before doing this.
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + File.separator + "Camera");
        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.
        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                //mLogger.debug("failed to create directory");
                return null;
            }
        }
        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File mediaFile;
        if (type == MEDIA_TYPE_IMAGE) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator + "IMG_" + timeStamp + ".jpg");
        } else if (type == MEDIA_TYPE_VIDEO) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator + "ePlusVID_" + timeStamp + ".mp4");
        } else {
            return null;
        }
        return mediaFile;
    }


    // 安全获取Camera对象实例的方法
    private static Camera getCameraInstance() {
        Camera c = null;
        try {
            c = Camera.open(); // 试图获取Camera实例

        } catch (Exception e) {
            // 摄像头不可用（正被占用或不存在）
        }
        return c; // 不可用则返回null
    }
}
